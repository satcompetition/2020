void bar(void)
{
}
