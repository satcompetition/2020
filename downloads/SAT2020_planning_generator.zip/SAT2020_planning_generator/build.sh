#!/usr/bin/env bash

echo "building PASAR"
mkdir pasar/build
cd pasar/sat/glucose4/
make
cd ../../build/
cmake ..
make pasar_glucose
cd ../..
cp pasar/build/pasar_glucose .

echo "building tree-rexx"
cd tree-rexx
make
cd ..
cp tree-rexx/treerexx .
