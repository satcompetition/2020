#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main("issue561-v3", "issue561-v4")
