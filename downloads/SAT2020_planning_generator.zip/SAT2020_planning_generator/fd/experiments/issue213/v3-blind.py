#! /usr/bin/env python
# -*- coding: utf-8 -*-

import itertools
import os

from lab.environments import LocalEnvironment, MaiaEnvironment

from downward.reports.compare import ComparativeReport

import common_setup
from common_setup import IssueConfig, IssueExperiment


BENCHMARKS_DIR = os.environ["DOWNWARD_BENCHMARKS"]
REVISIONS = ["issue213-v2", "issue213-v3"]
BUILDS = ["release32", "release64"]
SEARCHES = [
    ("blind", "astar(blind())"),
]
CONFIGS = [
    IssueConfig(
        "{nick}-{build}".format(**locals()),
        ["--search", search],
        build_options=[build],
        driver_options=["--build", build])
    for nick, search in SEARCHES
    for build in BUILDS
]
SUITE = common_setup.DEFAULT_OPTIMAL_SUITE
ENVIRONMENT = MaiaEnvironment(
    priority=0, email="jendrik.seipp@unibas.ch")

if common_setup.is_test_run():
    SUITE = IssueExperiment.DEFAULT_TEST_SUITE
    ENVIRONMENT = LocalEnvironment(processes=1)

exp = IssueExperiment(
    revisions=REVISIONS,
    configs=CONFIGS,
    environment=ENVIRONMENT,
)
exp.add_suite(BENCHMARKS_DIR, SUITE)

exp.add_absolute_report_step()

algorithm_pairs = []
revision1, revision2 = REVISIONS
for build in BUILDS:
    for config_nick, search in SEARCHES:
            algorithm_pairs.append(
                ("{revision1}-{config_nick}-{build}".format(**locals()),
                 "{revision2}-{config_nick}-{build}".format(**locals()),
                 "Diff ({config_nick}-{build})".format(**locals())))
exp.add_report(
    ComparativeReport(
        algorithm_pairs,
        attributes=IssueExperiment.DEFAULT_TABLE_ATTRIBUTES),
    name="issue213-v2-vs-v3-blind")

exp.run_steps()
