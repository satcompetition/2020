#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue549-base", "issue549-v3"])
