#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(combinations=[("issue571-base", "issue571-base", "issue571-base-v2"), ("issue571-base", "issue571-base", "issue571-v7"), ("issue571-base", "issue571-base", "issue571-v8")])
