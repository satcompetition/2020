#!/usr/bin/env bash

cd /home/froleyks/Dropbox/mt/pasar
scp -r src i10login.iti.kit.edu:/home/froleyks/pasar
ssh i10login.iti.kit.edu python3 /home/froleyks/pasar/version.py
gnome-terminal -e "bash -c \"ssh i10login.iti.kit.edu; exec zsh\""
