#pragma once

#include "src/abstraction/unrelaxed.hpp"

class Foreach : public Unrelaxed {
public:
  Foreach(Problem &problem, bool cegar = false) : Unrelaxed(problem) {
    if (cegar) {
      toggleFrame();
    } else {
      frame();
      refine(); // all
    }
  }

  inline void refine(const AbstractPlan::Step &actions) {
    std::vector<std::pair<action_t, action_t>> edgeList;
    getInterferenceGraph(actions, edgeList);
    refine(edgeList);
  }

  inline void refine() {
    addNewActions();
    std::vector<std::pair<action_t, action_t>> edgeList;
    getInterferenceGraph(edgeList);
    LOG(3) << "adding all interferences on " << edgeList.size() << " edges";
    refine(edgeList);
  }

  inline void refine(std::vector<std::pair<action_t, action_t>> &edgeList) {
    // remove cycles of length 2
    std::sort(edgeList.begin(), edgeList.end(), [](auto a, auto b) {
      action_t minA = std::min(a.first, a.second);
      action_t maxA = std::max(a.first, a.second);
      action_t minB = std::min(b.first, b.second);
      action_t maxB = std::max(b.first, b.second);
      return minA < minB ||
             (minA == minB &&
              (maxA < maxB || (maxA == maxB && a.first < b.first)));
    });
    size_t insert = 0;
    size_t i;
    for (i = 0; i < edgeList.size() - 1; ++i) {
      edgeList[insert++] = edgeList[i];
      if (edgeList[i].first == edgeList[i + 1].second &&
          edgeList[i].second == edgeList[i + 1].first) {
        i++;
      }
    }
    if (i < edgeList.size()) {
      edgeList[insert++] = edgeList[i];
    }
    edgeList.erase(edgeList.begin() + static_cast<long>(insert),
                   edgeList.end());
    edgeList.shrink_to_fit();
    addMutexes(edgeList);
  }
};
