#!/usr/bin/env python3

import multiprocessing
import os
import time
from glob import glob
import random
from shutil import rmtree
from subprocess import getstatusoutput as cmd
from sys import argv


def readInstances(file):
    inst = []
    f = open(file, 'r')
    for l in f:
        i = [e.strip() for e in l.split('|')][1:-1]
        i[2] = '../' + i[2]
        i[3] = '../' + i[3]
        inst.append(tuple(i))
    return inst


def generate(i):
    name = i[0] + '_' + '_'.join(i[3].split('/')[-3:]) + '_' + i[4]
    dir = 'TMP_' + name
    cnfFile = outDir + '/' + i[1] + '_' + name + '.cnf'
    os.mkdir(dir)
    c = 'cd ' + dir + ' && '

    if 'M' in i[0]:
        c += '../Mp -A 1 -S 1 -O -F ' + i[4] + \
            ' -T ' + i[4] + ' ' + i[2] + " " + i[3]
        if 'MS' in i[0]:
            c += ' -P 0'

    if 'P' in i[0]:
        c += '../fd/src/translate/translate.py ' + i[2] + ' ' + i[3] + ' && '
        c += '../pasar_glucose -v 9 -s 4 -mi 1 -i 0 -ml -1 -im ' + \
            i[4] + " -of ../" + cnfFile + " output.sas"

    if 'H' in i[0]:
        c += '../treerexx -of -d=' + i[4] + \
            ' -D=' + i[4] + ' ' + i[2] + ' ' + i[3]

    print('start ' + name)
    t1 = time.time()
    log = c
    log += '\n' + cmd(c)[1]
    t = time.time() - t1
    log += '\ngenerationTime: ' + str(t)

    if 'M' in i[0]:
        for l in log.split('\n'):
            if "Writing" in l:
                resFile = l.split(' ')[1]
        os.rename(dir + '/' + resFile, cnfFile)
    if 'H' in i[0]:
        os.rename(dir + '/f.cnf', cnfFile)

    rmtree(dir)
    with open(logDir + '/' + name + '.log', 'w') as f:
        f.write(log)
    return 'done  ' + name


def runInParallel(commands, threads):
    with multiprocessing.Pool(threads) as p:
        for i in p.imap_unordered(generate, commands):
            print(i)


cmd('./build.sh')
logDir = 'log'
outDir = 'planning'

if not os.path.exists(logDir):
    os.makedirs(logDir)
if not os.path.exists(outDir):
    os.makedirs(outDir)

for tmp in glob('TMP_*'):
    rmtree(tmp)

caldera = readInstances('caldera.org')
runInParallel(caldera, 1)

rest = readInstances('instances.org')

# advanced load balancing
random.seed(42)
random.shuffle(rest)

n = 16
if len(argv) > 1:
    n = int(argv[1])

runInParallel(rest, n)
