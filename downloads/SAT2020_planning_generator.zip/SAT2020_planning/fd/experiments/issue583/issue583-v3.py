#! /usr/bin/env python
# -*- coding: utf-8 -*-

from main import main

main(revisions=["issue583-base-v2", "issue583-v3"])
