file(REMOVE_RECURSE
  "CMakeFiles/cpfiels"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/cpfiels.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
