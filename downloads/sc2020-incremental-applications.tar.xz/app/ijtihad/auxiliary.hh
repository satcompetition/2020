/* 
 * File:   auxiliary.hh
 * Author: mikolas
 *
 * Created on October 12, 2011
 */

#ifndef AUXILIARY_HH
#define  AUXILIARY_HH

#include <sys/time.h>
#include <sys/resource.h>

static inline double read_cpu_time()
{
  struct rusage ru;
  getrusage(RUSAGE_SELF, &ru);
  return (double) ru.ru_utime.tv_sec + (double) ru.ru_utime.tv_usec / 1000000;
}

#endif	/* AUXILIARY_HH */

