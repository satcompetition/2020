Homepage: https://www.iaik.tugraz.at/content/research/opensource/ijtihad/

Ijtihad is a solver for Quantified Boolean Formulas (QBFs). The solver tackles 
the a formula iteratively, using counterexample-guided expansion. More details
can be found in the paper we submitted to the SAT conference 2017. While the 
ijtihad algorithm is applicable to any QBF in the prenex form, the current 
implementation supports only the QDIMACS format.

DepQBF 5.01 is also included as a library and used for calculating dependencies
between existential and universal variables. The usage of dependencies can be
turned on with one of the runtime command line options.

The submitted version will use these options:
- Dependencies provided by depqbf.
- All witnesses found in one call are used for expanding the formula of the 
universaly quantified variables.
- Trimming of the formula of the existentialy quantified variables every 200 
sat calls. 

The solver is called in this format:

./<SOLVER> <OPTIONS> <FILENAME>

We sugest a cooperation with the organisers of QBFEval'17, as they can provide
the benchmark set used in the QBF evaluation this year. If such an cooperation 
is not possible for organisational reasons, we suggest using both the 2014 and 
2016 QBFeval benchmark sets available at [1,2].

[1] http://www.qbflib.org/eval16.html
[2] http://qbf.satisfiability.org/gallery/
