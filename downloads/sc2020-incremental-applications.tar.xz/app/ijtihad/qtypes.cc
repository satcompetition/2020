#include "qtypes.hh"
#include <string>
#include <sstream>
#include "debug.hh"

SolverOptions::SolverOptions() :
    heretic_learn(DEFAULT_HERETIC_LEARN),
    reorder(DEFAULT_REORDER),
    scoring(DEFAULT_SCORING),
    variable_elimination(DEFAULT_VARIABLE_ELIMINATION),
    deduplication(DEFAULT_DEDUPLICATION),
    dependencies(DEFAULT_DEPENDENCIES),
    dep_timeout(DEFAULT_DEP_TIMEOUT),
    cex_per_call(DEFAULT_CEX_PER_CALL),
    wit_per_call(DEFAULT_WIT_PER_CALL),
    cex_order(DEFAULT_CEX_ORDER),
    wit_order(DEFAULT_WIT_ORDER),
    trimming_phi(DEFAULT_TRIMMING_PHI),
    trimming_interval(DEFAULT_TRIMMING_INTERVAL),
    trimming_base(DEFAULT_LUBY_BASE),
    heretic_mode(DEFAULT_HERETIC_MODE),
    heretic_clause_size(DEFAULT_HERETIC_MAX_CLAUSE_SIZE),
    qdpll_timeout(DEFAULT_DEPQBF_TIMEOUT),
    heretic_period(DEFAULT_HERETIC_PERIOD)
{ }

bool SolverOptions::parse(int argc, char** argv)
{
  debugn("Parsing options:");
  
  if(argc >= 2 && std::string(argv[1]) == "--help") return false;
  
  long vall = 0;
  std::string vals = "";
  
  bool hl = DEFAULT_HERETIC_LEARN;
  bool rq = DEFAULT_REORDER;
  bool sc = DEFAULT_SCORING;
  bool ve = DEFAULT_VARIABLE_ELIMINATION;
  bool ded = DEFAULT_DEDUPLICATION;
  bool dep = DEFAULT_DEPENDENCIES;
  long dt = DEFAULT_DEP_TIMEOUT;
  unsigned long cpc = DEFAULT_CEX_PER_CALL;
  unsigned long wpc = DEFAULT_WIT_PER_CALL;
  long co = DEFAULT_CEX_ORDER;
  long wo = DEFAULT_WIT_ORDER;
  TrimmingMode trim_phi = DEFAULT_TRIMMING_PHI;
  unsigned long trim_int = DEFAULT_TRIMMING_INTERVAL;
  unsigned long trim_base = DEFAULT_LUBY_BASE;
  HereticMode hm = DEFAULT_HERETIC_MODE;
  long hcs = DEFAULT_HERETIC_MAX_CLAUSE_SIZE;
  long fpt = DEFAULT_DEPQBF_TIMEOUT;
  long hp  = DEFAULT_HERETIC_PERIOD;
  
  for (int position = 1; position < argc - 1; position++)
  {
    std::string option(argv[position]);
    std::stringstream value("", std::ios::in);
    unsigned long eq;
    debugn("option " << position << " : " << option);
    if (option.find("--") == 0)
    {
      eq = option.find("=");
      if (eq != std::string::npos && eq + 1 < option.size())
      {
        value.str(option.substr(eq + 1));
        value >> vall;
        value.clear();
        value.str(option.substr(eq + 1));
        value >> vals;
        value.clear();
        value.str(option.substr(eq + 1));
        
        option = option.substr(0, eq);
        debugn("After splitting: " << option << " " << value.str() << " " << vall << " " << vals);
      }
        
      if (option == "--heretic_learn")
      {
        if (eq == std::string::npos || (bool) vall)
          hl = true;
        else
          hl = false;
      }
      else if (option == "--reorder")
      {
        if (eq == std::string::npos || (bool) vall)
          rq = true;
        else
          rq = false;
      }
      else if (option == "--scoring")
      {
        if (eq == std::string::npos || (bool) vall)
          sc = true;
        else
          sc = false;
      }
      else if (option == "--variable_elimination")
      {
        if (eq == std::string::npos || (bool) vall)
          ve = true;
        else
          ve = false;
      }
      else if (option == "--deduplication")
      {
        if (eq == std::string::npos || (bool) vall)
          ded = true;
        else
          ded = false;
      }
      else if (option == "--dependencies")
      {
        if (eq == std::string::npos || (bool) vall)
          dep = true;
        else
          dep = false;
      }
      else if (option == "--dep_timeout" && eq != std::string::npos)
      {
        if (vall > 1)
        {
          dt = vall;
        }
        else
        {
          debugn("dep_timeout cannot have such a short timeout, default value used instead");
        }
      }
      else if (option == "--cex_per_call" && eq != std::string::npos)
      {
        if (vall < 0)
        {
          debugn("cex_per_call has a negative value, defaulting to all");
          vall = -1;
        }
        cpc = (unsigned long) vall;
      }
      else if (option == "--wit_per_call" && eq != std::string::npos)
      {
        if (vall < 0)
        {
          debugn("wit_per_call has a negative value, defaulting to all");
          vall = -1;
        }
        wpc = (unsigned long) vall;
      }
      else if (option == "--cex_order" && eq != std::string::npos)
      {
        co = (vall < 0) ? -1 : 1;
      }
      else if (option == "--wit_order" && eq != std::string::npos)
      {
        wo = (vall < 0) ? -1 : 1;
      }
      else if (option == "--trimming_phi" && eq != std::string::npos)
      {
        if(vals == "periodic")
        {
          trim_phi = PERIODIC_TRIMMING;
        }
        else if(vals == "luby")
        {
          trim_phi = LUBY_TRIMMING;
        }
        else if(vals == "none")
        {
          trim_phi = NO_TRIMMING;
        }
        else
        {
          debugn("Trimming option is not valid");
        }
      }
      else if (option == "--heretic_mode" && eq != std::string::npos)
      {
        if(vals == "periodic")
        {
          hm = PERIODIC_HERESY;
        }
        else if(vals == "phase")
        {
          hm = PHASE_HERESY;
        }
        else if(vals == "none")
        {
          hm = NO_HERESY;
        }
        else
        {
          debugn("Heretic mode option is not valid");
        }
      }
      else if (option == "--trimming_interval"  && eq != std::string::npos)
      {
        if(vall > 5)
        {
          trim_int = (unsigned long)vall;
        }
        else
        {
          debugn("Cannot set the trimming interval to less than 5 calls");
        }
      }
      else if (option == "--trimming_base"  && eq != std::string::npos)
      {
        if(vall >= 1)
        {
          trim_base = (unsigned long)vall;
        }
        else
        {
          debugn("Cannot set the trimming luby base to less than 1");
        }
      }
      else if (option == "--heretic_clause_size"  && eq != std::string::npos)
      {
        if(vall >= 1)
        {
          hcs = (unsigned long)vall;
        }
        else
        {
          debugn("Cannot set the clause size to less than 1");
        }
      }
      else if (option == "--qdpll_timeout" && eq != std::string::npos)
      {
        if(vall >= 1)
        {
          fpt = (unsigned long)vall;
        }
        else
        {
          debugn("Cannot set the first phase timeout to less than 1");
        }
      }
      else if (option == "--heretic_period" && eq != std::string::npos)
      {
        if (vall > 1)
        {
          hp = vall;
        }
        else
        {
          debugn("heretic_period cannot have such a short timeout, default value used instead");
        }
      }
      else
      {
        debugn("Unknown opiton or no argument provided: " << option << " , aborting.");
        return false;
      }
    }
    else
    {
      debugn("option " << position << " has wrong format, aborting.");
      return false;
    }
  }
  
  heretic_learn = hl;
  reorder = rq;
  scoring = sc;
  variable_elimination = ve;
  deduplication = ded;
  dependencies = dep;
  dep_timeout = dt;
  cex_per_call = cpc;
  wit_per_call = wpc;
  cex_order = co;
  wit_order = wo;
  trimming_phi = trim_phi;
  trimming_interval = trim_int;
  trimming_base = trim_base;
  heretic_mode = hm;
  heretic_clause_size = hcs;
  qdpll_timeout = fpt;
  heretic_period = hp;
  
  cout  << "c Options after parsing: "
        << "\nc heretic_learn = " << heretic_learn
        << "\nc reorder = " << reorder
        << "\nc scoring = " << scoring
        << "\nc variable_elimination = " << variable_elimination
        << "\nc deduplication = " << deduplication
        << "\nc dependencies = " << dependencies
        << "\nc dep_timeout = " << dep_timeout
        << "\nc cex_per_call = " << cex_per_call
        << "\nc wit_per_call = " << wit_per_call
        << "\nc cex_order = " << cex_order
        << "\nc wit_order = " << wit_order
        << "\nc trimming_phi = " << trimming_phi
        << "\nc trimming_interval = " << trimming_interval
        << "\nc trimming_base = " << trimming_base
        << "\nc heretic_mode = " << heretic_mode
        << "\nc heretic_clause_size = " << heretic_clause_size
        << "\nc qdpll_timeout = " << qdpll_timeout
        << "\nc heretic_period = " << heretic_period
        << std::endl;
  return true;
}

Var var(Lit lit)
{ return (lit < 0) ? (Var) (-lit) : (Var) lit; }

bool sign(Lit lit)
{ return (lit < 0); }

Lit mkLit(Var v, bool sign)
{ return ((sign) ? -1 : 1) * (Lit) v; }

Lit negateLit(Lit lit)
{ return -lit; }

bool orderLits(Lit a, Lit b)
{
  if (a == -b)
  {
    return a < b;
  }
  else
  {
    a = (a < 0) ? -a : a;
    b = (b < 0) ? -b : b;
    return a < b;
  }
}

VarScore::VarScore(Var vi, unsigned si) :
    v(vi), score(si)
{}

bool operator<(const VarScore& a, const VarScore& b)
{
  return (a.score < b.score);
}

DependencyPair::DependencyPair(const vector<Var>& t, const vector<Var>& b) :
    top(t), bottom(b)
{}

Quantification::Quantification(const QuantifierType q, const vector<Var>& vars) :
  first(q), second(vars)
{ }

Quantification::Quantification() :
  first(EXISTENTIAL)
{}

bool operator==(const vector<Var>& a, const vector<Var>& b)
{
  if (a.size() != b.size())
    return false;
  for (unsigned i = 0; i < a.size(); i++)
  {
    if (a[i] != b[i])
      return false;
  }
  
  return true;
}


ostream& operator<<(ostream& outs, const CNF& f)
{
  outs << '[';
  for (const vector<Lit>& c : f)
  {
    outs << "[";
    for (const Lit& l : c)
      outs << " " << l;
    outs << " ]";
  }
  outs << "]";
  return outs;
}

/*
ostream &operator<<(ostream &outs, const QuantifiedFormula &f)
{
  outs << "[" << f.pref << "]" << f.cnf;
  return outs;
}
*/
ostream& operator<<(ostream& outs, QuantifierType q)
{
  switch (q)
  {
    case UNIVERSAL:
      return outs << "A";
      break;
    case EXISTENTIAL:
      return outs << "E";
      break;
    default:
      assert(0);
      return outs << "?";
  }
}

ostream& operator<<(ostream& outs, const Prefix& p)
{
  for (const Quantification& qi : p)
  {
    outs << '[' << (qi.first == EXISTENTIAL ? 'e' : 'a');
    outs << " ";
    outs << qi.second;
    outs << ']' << std::endl;
  }
  return outs;
}

ostream& operator<<(ostream& outs, const vector<Var>& vs)
{
  for (const Var& v: vs) outs << " " << v;
  return outs;
}

ostream& operator<<(ostream& outs, const vector<Lit>& ls)
{
  for (const Lit& l: ls) outs << " " << l;
  return outs;
}