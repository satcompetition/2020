//
// Created by vedad on 7/28/16.
//

#include "MySolver.hh"
#include <set>
#include "debug.hh"
#include <assert.h>
#include <algorithm>
#include "auxiliary.hh"
#include <queue>
#include <sstream>

extern "C"
{
#include "ipasir.h"
#include "depqbf/qdpll.h"
}

#define INDEX_PHI(v) ((v >> 1) + 1)
#define INDEX_KSI(v) ((v >> 1))

#define LAYERP_INDEX(v) (v >> 1)
#define LAYERK_INDEX(v) ((v >> 1) - 1)

#define LAYERP_INVERSE(i) ((i << 1) + 1)
#define LAYERK_INVERSE(i) ((i + 1) << 1)

using std::endl;

#ifndef VERSION
#define VERSION "v890"
#endif

MySolver::MySolver(Prefix& pref, const CNF& cnf, const SolverOptions* options) :
    max_id_(0),
    ready_solvers_(0),
    result_(0),
    sat_calls_(0),
    num_vars_phi_(0),
    num_vars_ksi_(0),
    layer_size_phi_(0),
    layer_size_ksi_(0),
    time_phi_(0.0),
    time_ksi_(0.0),
    time_(0.0),
    current_luby_counter_(0),
    luby_u_(1),
    luby_v_(1)
{
  printVersion();
  debugn("Creating MySolver.");
  
  if (options == NULL)
    options_ = SolverOptions();
  else
    options_ = *options;
  
  sat_solver_phi_ = ipasir_init();
  sat_solver_ksi_ = ipasir_init();
  
  debugn("Solver PHI is : " << sat_solver_phi_ << endl << "Solver KSI is: " << sat_solver_ksi_);
  
  // TODO: think about refactoring this
  
  debugn("There are " << pref.size() << " quantifiers.");
  
  if (pref.size() == 0)
    pref.push_back(Quantification(EXISTENTIAL, vector<Var>()));
  
  if (pref.size() == 1 && pref.front().first == EXISTENTIAL)
    pref.push_back(Quantification(UNIVERSAL, vector<Var>()));
  
  if (pref.front().first == UNIVERSAL)
    pref.insert(pref.begin(), Quantification(EXISTENTIAL, vector<Var>()));
  
  if (pref.back().first == UNIVERSAL)
    pref.push_back(Quantification(EXISTENTIAL, vector<Var>()));
  
  debugn("After adjustment there are " << pref.size() << " quantifiers.");
  
  if (options_.reorder)
  {
    reorderQuantifiersInternally(pref, cnf);
  }
  
  renameVariables(pref, cnf);
  
  if(options_.heretic_mode != SolverOptions::HereticMode::NO_HERESY || options_.dependencies)
    instantiateDepQBF();
  
  if (options_.dependencies)
    retrieveDependencies();
  
  if (formula_.pref.size() % 2 != 1 || formula_.pref[0].first != EXISTENTIAL)
  {
    debugn("Error: prefix size is " << formula_.pref.size() << ", first quantificator is " \
      << ((formula_.pref[0].first == EXISTENTIAL) ? "EXISTENTIAL" : "UNIVERSAL"));
    return;
  }
  
  debug(cout << formula_.pref << formula_.cnf << endl);
  
  for (unsigned i = 1; i <= independent_phi_.size(); i++)
  {
    newVarPHI();
  }
  
  empty_layer_phi_.resize(layer_size_phi_, 0);
  empty_layer_ksi_.resize(layer_size_ksi_, 0);
  
  for(unsigned i = 1; i <= layer_size_phi_; i++)
    tuple_base_phi_.push_back(i);
  
  for(unsigned i = 1; i <= layer_size_ksi_; i++)
    tuple_base_ksi_.push_back(i);
}

MySolver::~MySolver()
{
  ipasir_release(sat_solver_phi_);
  ipasir_release(sat_solver_ksi_);
  for(vector<Var>* b : layer_caluese_bases_)
    delete b;
}

int MySolver::warmStart()
{
  void* warmup_solver = ipasir_init();
  for(vector<Lit>& clause : formula_.cnf)
  {
    addClause(warmup_solver, clause);
  }
  
  if(ipasir_solve(warmup_solver) == 10)
  {
    if(layer_size_ksi_ == 0) return 10; // the SAT problem is satisfied
    
    LitTuple addition(&tuple_base_ksi_);
    vector<bool> addt;
    
    // instantiate all positive
    addt.assign(layer_size_ksi_, false);
    addition.assign(addt);
    counterexample_cache_.insert(addition);
    cex_to_add_.push_back(addition);
    
    // instantiate all negative
    addt.assign(layer_size_ksi_, true);
    addition.assign(addt);
    counterexample_cache_.insert(addition);
    cex_to_add_.push_back(addition);
    
    // instantiate only one quantifier negative
    unsigned q_index = 0;
    for (unsigned quant_index = 0; quant_index < formula_.pref.size(); quant_index++)
    {
      Quantification& q = formula_.pref[quant_index];
      if(q.first == UNIVERSAL)
      {
        addt.assign(layer_size_ksi_, false);
        for(unsigned v_index = 0; v_index < q.second.size(); v_index++)
        {
          addt[q_index] = true;
          q_index += 1;
        }
        addition.assign(addt);
        if(counterexample_cache_.find(addition) == counterexample_cache_.end())
        {
          counterexample_cache_.insert(addition);
          cex_to_add_.push_back(addition);
        }
      }
    }
    
    // instantiate only one qunatifier positive
    q_index = 0;
    for (unsigned quant_index = 0; quant_index < formula_.pref.size(); quant_index++)
    {
      Quantification& q = formula_.pref[quant_index];
      if(q.first == UNIVERSAL)
      {
        addt.assign(layer_size_ksi_, true);
        for(unsigned v_index = 0; v_index < q.second.size(); v_index++)
        {
          addt[q_index] = false;
          q_index += 1;
        }
        addition.assign(addt);
        if(counterexample_cache_.find(addition) == counterexample_cache_.end())
        {
          counterexample_cache_.insert(addition);
          cex_to_add_.push_back(addition);
        }
      }
    }
    
    // instantiate with the found solution of universials
    addt.clear();
    for (unsigned quant_index = 0; quant_index < formula_.pref.size(); quant_index++)
    {
      Quantification& q = formula_.pref[quant_index];
      if(q.first == UNIVERSAL)
      {
        for(Var& v : q.second)
        {
          addt.push_back(sign((Lit) ipasir_val(warmup_solver, v)));
        }
      }
    }
    
    addition.assign(addt);
    if(counterexample_cache_.find(addition) == counterexample_cache_.end())
    {
      counterexample_cache_.insert(addition);
      cex_to_add_.push_back(addition);
    }
    
    ipasir_release(warmup_solver);
    
    unsigned long cpc = options_.cex_per_call;
    options_.cex_per_call = (unsigned long)-1;
    
    extendPHI();
    options_.cex_per_call = cpc;
    
    return 0;
  }
  else
  {
    // no assignment of the universials solves the QBF, UNSAT
    return 20;
  }
}

void MySolver::learnClausesFromDepQBF(unsigned first, unsigned last)
{
  unsigned num_learned = qdpll_get_num_learned_clauses(depqbf_);
  num_learned = (num_learned > last - first) ? (last - first) : num_learned;
  
  int** qdpll_learned_clauses = new int*[num_learned];
  unsigned* qdpll_learned_clause_sizes = new unsigned int[num_learned];
  
  unsigned num_retreived = qdpll_get_learned_clauses(depqbf_, qdpll_learned_clauses, qdpll_learned_clause_sizes,
                                                     first, last, num_learned, options_.heretic_clause_size);
  
  cout << "c Heretic mode learned " << num_retreived << " clauses" << endl;
  // assert(num_learned == num_retreived);
  
  vector<Lit> clause_part_phi;
  vector<Lit> clause_part_ksi;
  vector<Lit> clause_whole;
  
  for (unsigned cl_index = 0; cl_index < num_retreived; cl_index++)
  {
    int* clause = qdpll_learned_clauses[cl_index];
    unsigned clause_size = qdpll_learned_clause_sizes[cl_index];
    
    clause_part_phi.clear();
    clause_part_ksi.clear();
    clause_whole.clear();
    for (unsigned lit_index = 0; lit_index < clause_size; lit_index++)
    {
      Lit literal = clause[lit_index];
      Var v = var(literal);
      
      if (v % 2 == 1)
      {
        clause_part_phi.push_back(literal);
      }
      else
      {
        clause_part_ksi.push_back(literal);
      }
      
      clause_whole.push_back(literal);
    }
    
    std::sort(clause_part_phi.begin(), clause_part_phi.end(), orderLits);
    std::sort(clause_part_ksi.begin(), clause_part_ksi.end(), orderLits);
    std::sort(clause_whole.begin(), clause_whole.end(), orderLits);
    
    // cout << "c learned clause " << clause_whole << endl;
    
    formula_.phi_part.push_back(clause_part_phi);
    formula_.ksi_part.push_back(clause_part_ksi);
    formula_.cnf.push_back(clause_whole);
  }
  
  delete[] qdpll_learned_clauses;
  delete[] qdpll_learned_clause_sizes;
}

bool MySolver::solve()
{
  double time0 = read_cpu_time();
  
  if(options_.heretic_mode == SolverOptions::HereticMode::PHASE_HERESY &&
      layer_size_ksi_ != 0 && options_.qdpll_timeout > 0)
  {
    std::stringstream depqbf_timeout("", std::ios::out);
    depqbf_timeout << "--max-secs=" << options_.qdpll_timeout;
    char* dtc = (char*)depqbf_timeout.str().c_str();
    cout << "c setting limit of depqbf to " << dtc << endl;
    qdpll_configure(depqbf_, dtc);
    // qdpll_configure(depqbf_, "--dep-man=simple");
    // qdpll_configure(depqbf_, "--incremental-use");
    QDPLLResult res = qdpll_sat (depqbf_);
    // if depqbf solved the formula by itself
    
    cout << "c DepQBF concluded with " << res << endl;
    if(res != QDPLL_RESULT_UNKNOWN)
    {
      qdpll_delete(depqbf_);
      return (res == QDPLL_RESULT_SAT);
    }
    else
    {
      if(options_.heretic_learn)
        learnClausesFromDepQBF(0, (unsigned)-1);
      
      qdpll_delete(depqbf_);
    }
  }
  
  int trivial = warmStart();
  if(trivial != 0)
  {
    return (trivial == 10);
  }
  
  cout << "c Running Ijtihad loop" << endl;
  
  double cegar_time = read_cpu_time();
  
  unsigned last_learned_id = 0;
  
  while (true)
  {
    if(options_.heretic_mode == SolverOptions::HereticMode::PERIODIC_HERESY &&
        read_cpu_time() - cegar_time > options_.heretic_period)
    {
      qdpll_reset(depqbf_);
      std::stringstream depqbf_timeout("", std::ios::out);
      depqbf_timeout << "--max-secs=" << options_.heretic_period;
      char* dtc = (char*)depqbf_timeout.str().c_str();
      cout << "c setting limit of depqbf to " << dtc << endl;
      qdpll_configure(depqbf_, dtc);
      qdpll_configure(depqbf_, "--dep-man=simple");
      qdpll_configure(depqbf_, "--incremental-use");
      QDPLLResult res = qdpll_sat (depqbf_);
      // if depqbf solved the formula by itself
  
      cout << "c DepQBF concluded with " << res << endl;
      if(res != QDPLL_RESULT_UNKNOWN)
      {
        qdpll_delete(depqbf_);
        return (res == QDPLL_RESULT_SAT);
      }
      else
      {
        
        if(options_.heretic_learn)
          learnClausesFromDepQBF(last_learned_id, (unsigned)-1);
        
        last_learned_id = qdpll_get_num_learned_clauses(depqbf_);
      }
      
      cegar_time = read_cpu_time();
    }
    
    
    debugn("Entring solver loop.");
    double time1 = read_cpu_time();
    bool phi_sat = (ipasir_solve(sat_solver_phi_) == 10);
    time_phi_ += read_cpu_time() - time1;
  
    if (phi_sat)
    {
      debugn("PHI is SAT");
      extendKSI();
    
      double time2 = read_cpu_time();
      bool ksi_sat = (ipasir_solve(sat_solver_ksi_) == 10);
      time_ksi_ += read_cpu_time() - time2;
    
      if (ksi_sat)
      {
        debugn("KSI is SAT");
        extendPHI();
      }
      else
      {
        debugn("KSI is UNSAT");
      
        time_ = read_cpu_time() - time0;
        return true;
      }
      sat_calls_++;
      current_luby_counter_++;
    }
    else
    {
      debugn("PHI is UNSAT");
    
      time_ = read_cpu_time() - time0;
      return false;
    }
  }
}

void MySolver::printStats()
{
  cout << "c sat_solver_phi calld " << sat_calls_
       << " times, running for " << time_phi_ << " seconds." << endl;
  cout << "c number of layers in PHI is " << layers_phi_.size() << endl;
  cout << "c sat_solver_ksi was running for " << time_ksi_ << " seconds." << endl;
  cout << "c number of layers in KSI is " << layers_ksi_.size() << endl;
  cout << "c mysolver was running for " << time_ << " seconds." << endl;
}

void MySolver::computeExtension(FormulaType type)
{
  debugn("computeExtension " << ((type == PHI) ? "PHI" : "KSI") << ": begin");
  long order = (type == PHI) ? options_.cex_order : options_.wit_order;
  unsigned long per_call = (type == PHI) ? options_.cex_per_call : options_.wit_per_call;
  vector<vector<Var>>& layers = (type == PHI) ? layers_ksi_ : layers_phi_;
  unsigned long layer_size = (type == PHI) ? layer_size_ksi_ : layer_size_phi_;
  void* sat_solver = (type == PHI) ? sat_solver_ksi_ : sat_solver_phi_;
  vector<LitTuple>& to_add_container = (type == PHI) ? cex_to_add_ : wit_to_add_;
  LitTupleSet& cache = (type == PHI) ? counterexample_cache_ : witness_cache_;
  vector<Var>* base = (type == PHI) ? &tuple_base_ksi_ : &tuple_base_phi_;
  LitTuple2Uint candidates;
  
  vector<bool> addt;
  addt.reserve(layer_size);
  
  LitTuple addition(base);
  
  long begin_layer_number = (order == 1) ? 0 : (layers.size() - 1);
  long end_layer_number = (order == 1) ? (long) layers.size() : -1;
  long layer_increment = (order == 1) ? 1 : -1;
  unsigned long added_layers = 0;
  bool scoring_needed = options_.scoring && (per_call < layers_phi_.size());
  
  // prepare extension
  for(long layer_number = begin_layer_number;
      added_layers < per_call && layer_number != end_layer_number;
      layer_number += layer_increment)
  {
    vector<Var>& layer = layers[layer_number];
    debugn("Layer number is " << layer_number);
    addt.clear();
    for (unsigned i = 0; i < layer_size; i++)
    {
      addt.push_back(sign((Lit) ipasir_val(sat_solver, layer[i])));
    }
    
    addition.assign(addt);
    
    if (cache.find(addition) != cache.end())
    {
      debugn("cache worked...");
      continue;
    }
    
    if(scoring_needed)
    {
      auto citer = candidates.find(addition);
      if (citer == candidates.end())
      {
        candidates.insert(std::pair<LitTuple,unsigned>(addition, 1));
      }
      else
      {
        citer->second += 1;
      }
    }
    else
    {
      cache.insert(addition);
  
      added_layers++;
      to_add_container.push_back(addition);
    }
  }
  
  if(scoring_needed)
  {
    std::priority_queue<LitTupleScore> candidates_queue;
  
    for(auto& citer : candidates)
    {
      candidates_queue.push(LitTupleScore(&(citer.first), citer.second));
    }
  
    for(unsigned i = 0; i < per_call && !candidates_queue.empty(); i++)
    {
      LitTupleScore lts = candidates_queue.top();
      candidates_queue.pop();
      debugn("Adding LitTuple " << ((type == PHI) ? "PHI " : "KSI ") << lts.lit_tuple->getHash() << " with score " << lts.score);
      cache.insert(*(lts.lit_tuple));
      to_add_container.push_back(*(lts.lit_tuple));
    }
  }
  debugn("computeExtension " << ((type == PHI) ? "PHI" : "KSI") << ": begin");
}

void MySolver::extendKSI()
{
  debugn("extendKSI: begin");
  
  vector<bool> ext;
  ext.reserve(layer_size_phi_);
  
  vector<vector<Lit>*> pending_clauses;
  
  LitTuple ext_key(nullptr);
  
  LitTuple layer_clause(nullptr);
  
  computeExtension(KSI);
  
  for (auto& wit_it : wit_to_add_)
  {
    bool cache_possible = true;
    bool skip = false;
    
    ext.clear();
    
    layers_ksi_.push_back(empty_layer_ksi_);
    
    vector<Var>& layer_k = layers_ksi_.back();
    
    if (!options_.dependencies)
    {
      for (unsigned quant_index = 0; quant_index < formula_.pref.size(); quant_index++)
      {
        Prefix::iterator quant_iter = formula_.pref.begin() + quant_index;
        Prefix::iterator quant_inc_iter = formula_.pref_inc.begin() + quant_index;
        if (quant_iter->first == EXISTENTIAL)
        {
          skip = false;
          for (const Var& v : quant_iter->second)
            ext.push_back(sign(wit_it[LAYERP_INDEX(v)]));
          ext_key.rebase(&(quant_inc_iter->second));
          if (cache_possible)
          {
            ext_key.assign(ext);
            const auto cache_iter = vars_cache_ksi_.find(ext_key);
            if (cache_iter != vars_cache_ksi_.end())
            {
              debugn("We have a variable cache hit: ");
              
              debug
              ({
                 cout << ext_key.getHash();
                 cout << "key : < ";
                 for (const bool& l : ext)
                 { cout << l << " "; }
                 cout << "> data: <";
                 for (const Var& v : cache_iter->second)
                 { cout << v << " "; }
                 cout << ">\n";
               });
              
              vector<Var>::iterator subst_iter = cache_iter->second.begin();
              for (const Var& v : (quant_iter + 1)->second)
              {
                layer_k[LAYERK_INDEX(v)] = *subst_iter;
                subst_iter++;
              }
              skip = true;
            }
            else
              cache_possible = false;
          }
        }
        else if (!skip) // && quant_iter->first == UNIVERSIAL
        {
          vector<Var> subst;
          for (const Var& v : quant_iter->second)
          {
            subst.push_back(newVarKSI());
            layer_k[LAYERK_INDEX(v)] = subst.back();
          }
          
          ext_key.assign(ext);
          // add to variable cache
          debug
          ({
             cout << ext_key.getHash();
             cout << " caching key: < ";
             for (const bool& l : ext)
             { cout << l << " "; }
             cout << "> data: <";
             for (const Var& v : subst)
             { cout << v << " "; }
             cout << ">\n";
           });
          vars_cache_ksi_[ext_key] = subst;
        }
      }
    }
    else
    {
      for (const auto& it : deps_ksi_)
      {
        ext.clear();
        
        for (const Var& d: it.top)
          ext.push_back(sign(wit_it[LAYERP_INDEX(d)]));
        ext_key.rebase(&(it.top));
  
        debug(cout << it.bottom << " : "; for (const bool& l : ext) { cout << l << " "; } cout << endl;);
        ext_key.assign(ext);
        const auto cache_iter = vars_cache_ksi_.find(ext_key);
        if (cache_iter != vars_cache_ksi_.end())
        {
          assert(it.bottom.size() == cache_iter->second.size());
          for (unsigned v_pos = 0; v_pos < it.bottom.size(); v_pos++)
          {
            layer_k[LAYERK_INDEX(it.bottom[v_pos])] = cache_iter->second[v_pos];
          }
          
          debugn("We have a variable cache hit: ");
          debug
          ({
             cout << ext_key.getHash();
             cout << " caching key: < ";
             for (const bool& l : ext)
             { cout << l << " "; }
             cout << "> data: <";
             for (const Var& v : cache_iter->second)
             { cout << v << " "; }
             cout << ">\n";
           });
        }
        else
        {
          vector<Var> subst;
          for (unsigned v_pos = 0; v_pos < it.bottom.size(); v_pos++)
          {
            subst.push_back(newVarKSI());
            layer_k[LAYERK_INDEX(it.bottom[v_pos])] = subst.back();
          }
          vars_cache_ksi_[ext_key] = subst;
        }
      }
    }
    
    debugn("Layer:\n");
    vector<Lit> global_nand;
    vector<Lit> literal_clause;
    literal_clause.reserve(2);
    vector<bool> layer_cl_sign;
    
    for (unsigned clause_num = 0; clause_num < formula_.phi_part.size(); clause_num++)
    {
      bool satisfied = false;
      for (const Lit& literal : formula_.phi_part[clause_num])
      {
        if (sign(literal) == sign(wit_it[LAYERP_INDEX(var(literal))]))
        {
          satisfied = true;
          break;
        }
      }
      
      if (satisfied) continue;
  
      vector<Var>* layer_cl_var = new vector<Var>();
      layer_cl_sign.clear();
      // TODO: isEliminated usage here
      
      for (const Lit& literal : formula_.ksi_part[clause_num])
      {
        layer_cl_var->push_back(layer_k[LAYERK_INDEX(var(literal))]);
        layer_cl_sign.push_back(sign(literal));
      }
      
      // layer_caluese_bases_.push_back(layer_cl_var);
      
      layer_clause.rebase(layer_cl_var);
      layer_clause.assign(layer_cl_sign);
      
      const auto cache_iter = tseitin_cache_.find(layer_clause);
      if (cache_iter != tseitin_cache_.end())
      {
        // debugn("cache worked...");
        delete layer_cl_var;
        global_nand.push_back(cache_iter->second);
        continue;
      }
  
      layer_caluese_bases_.push_back(layer_cl_var);
      
      Lit x_i = mkLit(newVarKSI(), true);
      
      global_nand.push_back(x_i);
      tseitin_cache_[layer_clause] = x_i;
      
      literal_clause.clear();
      literal_clause.push_back(negateLit(x_i));
      literal_clause.push_back(mkLit(0));
      
      for (unsigned lit_index = 0; lit_index < layer_clause.size(); lit_index++)
      {
        literal_clause[1] = negateLit(layer_clause[lit_index]);
        if (options_.variable_elimination)
        {
          pending_clauses.push_back(new vector<Lit>(literal_clause));
        }
        else
        {
          addClause(sat_solver_ksi_, literal_clause);
          debugn("extendKSI: " << literal_clause);
        }
      }
    }
    if (options_.variable_elimination)
    {
      pending_clauses.push_back(new vector<Lit>(global_nand));
    }
    else
    {
      addClause(sat_solver_ksi_, global_nand);
      debugn("extendKSI: " << global_nand);
    }
  }
  
  wit_to_add_.clear();
  
  cout << endl;
  
  if (options_.variable_elimination)
  {
    performVariableElimination(KSI, pending_clauses);
    
    for (vector<Lit>* cl : pending_clauses)
    {
      debugn("extendKSI: " << *cl);
      addClause(sat_solver_ksi_, *cl);
      delete cl;
    }
    
  }
  
  debugn("extendKSI: end");
}

void MySolver::extendPHI()
{
  debugn("extendPHI: begin");
  
  vector<bool> uni;
  uni.reserve(layer_size_ksi_);
  
  vector<vector<Lit>*> pending_clauses;
  
  LitTuple uni_key(nullptr);
  
  cout << "c Number of calls is: " << sat_calls_ << endl
       << "c Layers in PHI: " << layers_phi_.size() << endl
       << "c Layers in KSI: " << layers_ksi_.size() << endl;
  
  unsigned long old_cpc = 0;
  bool trim_periodic = options_.trimming_phi == SolverOptions::TrimmingMode::PERIODIC_TRIMMING &&
      (sat_calls_ % options_.trimming_interval == 0) &&
      (sat_calls_ != 0);
  bool trim_luby = options_.trimming_phi == SolverOptions::TrimmingMode::LUBY_TRIMMING &&
      (current_luby_counter_ == luby_v_ * options_.trimming_base);
  
  if(trim_luby)
  {
    current_luby_counter_ = 0;
    updateLuby();
  }
  
  if(trim_periodic || trim_luby)
  {
    std::cout << "c Trimming PHI" << endl;
    ipasir_release(sat_solver_phi_);
    sat_solver_phi_ = ipasir_init();
    
    counterexample_cache_.clear();
    
    vars_cache_phi_.clear();
    num_vars_phi_ = 0;
    for (unsigned i = 1; i <= independent_phi_.size(); i++)
    {
      newVarPHI();
    }
    layers_phi_.clear();
    old_cpc = options_.cex_per_call;
    options_.cex_per_call = (unsigned long)-1;
  }
  
  computeExtension(PHI);
  
  // restore cpc
  if(trim_periodic || trim_luby)
  {
    options_.cex_per_call = old_cpc;
  }
    
  for (auto& cex_it : cex_to_add_)
  {
    // counterexample_cache_.insert(cex_it.second);
    
    bool cache_possible = true;
    bool skip = false;
    
    uni.clear();
    
    layers_phi_.push_back(empty_layer_phi_);
    
    vector<Var>& layer_p = layers_phi_.back();
    
    for (unsigned int i = 0; i < independent_phi_.size(); i++)
    {
      layer_p[LAYERP_INDEX(independent_phi_[i])] = i + 1;
    }
    
    if (!options_.dependencies)
    {
      // add a new layer of existentials
      // if a value assignment for universals that are upstream
      // from some existentials was already encountered once, then
      // reuse the same existential substitutions, to boost performance
      // otherwise, create new variables as substitutions and add them
      // to both layer and cache
      for (unsigned quant_index = 1; quant_index < formula_.pref.size(); quant_index++)
      {
        Prefix::iterator quant_iter = formula_.pref.begin() + quant_index;
        Prefix::iterator quant_inc_iter = formula_.pref_inc.begin() + quant_index;
        
        if (quant_iter->first == UNIVERSAL)
        {
          skip = false;
          for (const Var& v : quant_iter->second)
            uni.push_back(sign(cex_it[LAYERK_INDEX(v)]));
          uni_key.rebase(&(quant_inc_iter->second));
          if (cache_possible)
          {
            uni_key.assign(uni);
            const auto cache_iter = vars_cache_phi_.find(uni_key);
            if (cache_iter != vars_cache_phi_.end())
            {
              debugn("We have a variable cache hit: ");
              debug
              ({
                 cout << uni_key.getHash();
                 cout << " key : < ";
                 for (const bool& l : uni)
                 { cout << l << " "; }
                 cout << ">data: <";
                 for (const Var& v : cache_iter->second)
                 { cout << v << " "; }
                 cout << ">\n";
               });
              
              vector<Var>::iterator subst_iter = cache_iter->second.begin();
              for (const Var& v : (quant_iter + 1)->second)
              {
                layer_p[LAYERP_INDEX(v)] = *subst_iter;
                subst_iter++;
              }
              skip = true;
            }
            else
              cache_possible = false;
          }
        }
        else if (!skip) // && quant_iter->first == EXISTENTIAL
        {
          vector<Var> subst;
          for (const Var& v : quant_iter->second)
          {
            subst.push_back(newVarPHI());
            layer_p[LAYERP_INDEX(v)] = subst.back();
          }
          
          uni_key.assign(uni);
          
          debug
          ({
             cout << uni_key.getHash();
             cout << " caching key: < ";
             for (const bool& l : uni)
             { cout << l << " "; }
             cout << "> data: <";
             for (const Var& v : subst)
             { cout << v << " "; }
             cout << ">\n";
           });
          
          // add to variable cache
          vars_cache_phi_[uni_key] = subst;
        }
      }
    }
    else
    {
      for (const auto& it : deps_phi_)
      {
        if (it.top.empty())
          continue;
        
        uni.clear();
        
        for (const Var& d: it.top)
        {
          uni.push_back(sign(cex_it[LAYERK_INDEX(d)]));
        }
        uni_key.rebase(&(it.top));
        
        debug(cout << it.bottom << " : "; for (const bool& l : uni) { cout << l << " "; } cout << endl;);
        uni_key.assign(uni);
        const auto cache_iter = vars_cache_phi_.find(uni_key);
        if (cache_iter != vars_cache_phi_.end())
        {
          assert(it.bottom.size() == cache_iter->second.size());
          for (unsigned v_pos = 0; v_pos < it.bottom.size(); v_pos++)
          {
            layer_p[LAYERP_INDEX(it.bottom[v_pos])] = cache_iter->second[v_pos];
          }
          
          debugn("We have a variable cache hit: ");
          debug
          ({
             cout << uni_key.getHash();
             cout << " caching key: < ";
             for (const bool& l : uni)
             { cout << l << " "; }
             cout << "> data: <";
             for (const Var& v : cache_iter->second)
             { cout << v << " "; }
             cout << ">\n";
           });
        }
        else
        {
          vector<Var> subst;
          for (unsigned v_pos = 0; v_pos < it.bottom.size(); v_pos++)
          {
            subst.push_back(newVarPHI());
            layer_p[LAYERP_INDEX(it.bottom[v_pos])] = subst.back();
          }
          
          vars_cache_phi_[uni_key] = subst;
        }
        debug(cout << "Replacement: ";
                  for (int i = 0; i < layer_size_phi_; i++) cout << layer_p[i] << " ";
                  cout << endl;);
        
      }
    }
    
    vector<Lit> cl;
    // LitTuple clause_key;
    cl.reserve(layer_size_phi_);
    for (unsigned clause_num = 0; clause_num < formula_.ksi_part.size(); clause_num++)
    {
      bool satisfied = false;
      for (const Lit& literal : formula_.ksi_part[clause_num])
      {
        if (sign(literal) == sign(cex_it[LAYERK_INDEX(var(literal))]))
        {
          satisfied = true;
          break;
        }
      }
      
      if (satisfied) continue;
      cl.clear();
      bool elim_value;
      
      for (const Lit& literal : formula_.phi_part[clause_num])
      {
        if (!options_.variable_elimination ||
            !isEliminated(PHI, layer_p[LAYERP_INDEX(var(literal))], elim_value))
        {
          cl.push_back(mkLit(layer_p[LAYERP_INDEX(var(literal))], sign(literal)));
        }
        else if (!elim_value == sign(literal)) // has to be negated because sign gives true on negated variables
        {
          satisfied = true;
          break;
        }
      }
      
      if (satisfied) continue;
       
      if (options_.variable_elimination)
      {
        pending_clauses.push_back(new vector<Lit>(cl));
      }
      else
      {
        addClause(sat_solver_phi_, cl);
        debugn("extendPHI: " << cl);
      }
    }
  }
  
  cex_to_add_.clear();
  
  cout << endl;
  
  if (options_.variable_elimination)
  {
    performVariableElimination(PHI, pending_clauses);
    
    for (vector<Lit>* cl : pending_clauses)
    {
      addClause(sat_solver_phi_, *cl);
      debugn("extendPHI: " << *cl);
      delete cl;
    }
  }
  debugn("extendPHI: end");
}

void MySolver::updateLuby()
{
  luby_u_ = (luby_u_ & -luby_u_ == luby_v_) ? luby_u_ + 1 : luby_u_;
  luby_v_ = (luby_u_ & -luby_u_ == luby_v_) ? 1 : 2 * luby_v_;
}

bool MySolver::isEliminated(FormulaType type, Var v, bool& elimination_value)
{
  if (v < 0) return false;
  
  vector<bool>& eliminated_status_from = (type == PHI) ? elimination_status_phi_ : elimination_status_ksi_;
  vector<bool>& eliminated_value_from = (type == PHI) ? elimination_value_phi_ : elimination_value_ksi_;
  
  if (eliminated_status_from.size() <= (unsigned) v)
  {
    eliminated_status_from.resize(v + 1, false);
    eliminated_value_from.resize(v + 1, false);
  }
  
  if (eliminated_status_from[v])
    elimination_value = eliminated_value_from[v];
  
  return eliminated_status_from[v];
}

void MySolver::eliminateVar(FormulaType type, Var v, bool value)
{
  if (v < 0) return;
  
  vector<bool>& eliminate_status_from = (type == PHI) ? elimination_status_phi_ : elimination_status_ksi_;
  vector<bool>& eliminate_value_from = ((type == PHI)) ? elimination_value_phi_ : elimination_value_ksi_;
  
  // if variable is checked for the first time, extend the vector
  if (eliminate_status_from.size() <= (unsigned) v)
  {
    eliminate_status_from.resize(v + 1, false);
    eliminate_value_from.resize(v + 1, false);
  }
  
  debug
  ({
     if (eliminate_status_from[v])
     {
       cout << "eliminateVar: Warning, multiple elimination of "
            << v << " from " << ((type == PHI) ? "PHI" : "KSI") << endl;
     }
   });
  
  eliminate_status_from[v] = true;
  eliminate_value_from[v] = value;
}

void MySolver::performVariableElimination(FormulaType type, vector<vector<Lit>*>& clauses)
{
  debugn("Performing variable elimination!");
  vector<Lit> elimination_stack;
  vector<Lit> elimination_done;
  std::set<Var> on_stack;
  vector<vector<Lit>*> touched;
  std::map<Lit, vector<unsigned> > occurances;
  
  // add literals from unit clauses to the stack
  for (vector<Lit>* clause : clauses)
  {
    if (clause->size() == 1)
    {
      Var v = var((*clause)[0]);
      
      if (on_stack.find(v) == on_stack.end())
      {
        elimination_stack.push_back((*clause)[0]);
        on_stack.insert(v);
      }
    }
  }
  
  debugn("Added " << elimination_stack.size() << " unit clauses");
  
  if (elimination_stack.empty())
    return;
  
  // construct occurance lists
  for (unsigned clause_num = 0; clause_num < clauses.size(); clause_num++)
  {
    vector<Lit>& clause = (*clauses[clause_num]);
    if (clause.size() != 0) // very important check
    {
      Lit* begin = &(clause[0]);
      Lit* end = begin + clause.size();
      for (Lit* l = begin; l < end; l++)
      {
        Lit ml = *l;
        if (occurances.find(ml) == occurances.end())
          occurances[ml] = vector<unsigned>();
        occurances[ml].push_back(clause_num);
      }
    }
  }
  
  debugn("Constructed occurance lists.");
  
  // do iterative variable elimination
  while (!elimination_stack.empty())
  {
    Lit elimination_lit = elimination_stack.back();
    Lit elimination_neg = negateLit(elimination_lit);
    elimination_stack.pop_back();
    
    // since all variables are known this should never return occurances.end()
    auto iter = occurances.find(elimination_lit);
    
    // check all clauses where the variable appears
    for (unsigned clause_num : iter->second)
    {
      vector<Lit>& clause = (*clauses[clause_num]);
      clause.clear();
      clause.push_back(mkLit(0));
    }
    
    iter = occurances.find(elimination_neg);
    if (iter != occurances.end())
    {
      for (unsigned clause_num : iter->second)
      {
        touched.push_back(clauses[clause_num]);
        vector<Lit>& clause = (*clauses[clause_num]);
        Lit* begin = &(clause[0]);
        Lit* end = begin + clause.size();
        for (Lit* l = begin; l < end; l++)
        {
          Lit ml = *l;
          if (elimination_neg == ml)
          {
            *l = clause.back();
            clause.pop_back();
            break;
          }
        }
        
      }
    }
    
    // remember that variable is eliminated
    eliminateVar(type, var(elimination_lit), !sign(elimination_lit));
    elimination_done.push_back(elimination_lit);
    
    debugn("Eliminated variable " << var(elimination_lit) << " in " << ((type == PHI) ? "PHI" : "KSI"));
    
    // add literals from newly created unit clauses to the stack
    
    for (vector<Lit>* clause : touched)
    {
      if (clause->size() == 1 && (*clause)[0] != mkLit(0))
      {
        Var v = var((*clause)[0]);
        
        if (on_stack.find(v) == on_stack.end())
        {
          elimination_stack.push_back((*clause)[0]);
          on_stack.insert(v);
        }
      }
    }
    touched.clear();
  }
  
  // copy all good clauses to new vector and reassign old vector
  vector<vector<Lit>*> remaining_clauses;
  remaining_clauses.reserve(clauses.size());
  
  for (vector<Lit>* clause : clauses)
  {
    if (!(clause->size() == 1 && (*clause)[0] == mkLit(0)))
    {
      remaining_clauses.push_back(clause);
    }
    else
    {
      // don't forget to dealloc
      delete clause;
    }
  }
  
  debug(unsigned total_removed_clauses = clauses.size() - remaining_clauses.size() - elimination_done.size(););
  
  clauses = remaining_clauses;
  
  // add unit clauses for eliminated variables, since they also get lost
  for (const Lit& l : elimination_done)
  {
    clauses.push_back(new vector<Lit>());
    clauses.back()->push_back(l);
  }
  
  debugn("performVariableElimination: Eliminated " << total_removed_clauses
                                                   << " clauses and " << elimination_done.size() << " variables from "
                                                   << ((type == PHI) ? "PHI" : "KSI"));
}

void MySolver::addClause(void* solver, vector<Lit>& clause)
{
  for (const Lit& l : clause)
  {
    ipasir_add(solver, l);
  }
  ipasir_add(solver, 0);
}

void MySolver::printVersion()
{
  cout << "c MySolver" << VERSION << std::endl;
}

void MySolver::reorderQuantifiersInternally(Prefix& pref, const CNF& cnf)
{
  std::map<Var, unsigned> scores_container;
  
  for (const vector<Lit>& clause : cnf)
  {
    for (const Lit& literal : clause)
    {
      Var v = var(literal);
      auto it = scores_container.find(v);
      if (it == scores_container.end())
      {
        it = scores_container.insert(std::make_pair(v, 0)).first;
      }
      
      it->second += 1;
    }
  }
  
  for (Quantification& q : pref)
  {
    vector<VarScore> quant_scores;
    vector<Var> reordered_quant;
    for (const Var& v : q.second)
    {
      auto it = scores_container.find(v);
      if (it != scores_container.end())
      {
        quant_scores.push_back(VarScore(v, it->second));
      }
      else
      {
        debugn("Fatal error: scores_container does not contain var " << v);
      }
    }
    std::sort(quant_scores.rbegin(), quant_scores.rend());
    debug(for (const VarScore& a : quant_scores)
          { cout << "( " << a.v << ", " << a.score << ") "; }
              cout << endl;);
    for (const VarScore& a : quant_scores)
    {
      reordered_quant.push_back(a.v);
    }
    q.second = reordered_quant;
  }
}

void MySolver::renameVariables(Prefix& pref, const CNF& cnf)
{
  // Rename the variables to eliminate the need for lookup tables.
  // The renaming scheme will go through the variables and rename
  // existentials to uneven and universals to even ids.
  
  // find size of renaming scheme lookup
  
  unsigned renaming_size[2];
  renaming_size[0] = 0;
  renaming_size[1] = 0;
  
  max_id_ = 0;
  for (const Quantification& q : pref)
  {
    unsigned* x = (q.first == EXISTENTIAL) ? &(renaming_size[0]) : &(renaming_size[1]);
    *x += q.second.size();
    for (const Var& v : q.second)
    {
      if (v > max_id_)
        max_id_ = v;
    }
  }
  
  renaming_scheme_.resize(2 * std::max(renaming_size[0], renaming_size[1]) + 1);
  std::vector<int> variable_depth;
  variable_depth.resize(2 * std::max(renaming_size[0], renaming_size[1]) + 1);
  names_phi_.resize((unsigned long) max_id_ + 1, (Var) -1);
  names_ksi_.resize((unsigned long) max_id_ + 1, (Var) -1);
  
  layer_size_phi_ = renaming_size[0];
  layer_size_ksi_ = renaming_size[1];
  
  // go through the variables as they appear in the prefix and assign new name
  // names
  Var e = 1;
  Var a = 2;
  // alternation
  int e_l = 0;
  int a_l = 1;
  
  Quantification quant_inc_e;
  Quantification quant_inc_a;
  
  quant_inc_e.first = EXISTENTIAL;
  quant_inc_a.first = UNIVERSAL;
  
  for (const Quantification& q : pref)
  {
    Quantification quant;
    quant.first = q.first;
    
    Quantification& quant_inc = (q.first == EXISTENTIAL) ? quant_inc_e : quant_inc_a;
    
    Var& x = (q.first == EXISTENTIAL) ? e : a;
    int& x_l = (q.first == EXISTENTIAL) ? e_l : a_l;
    vector<Var>& names = (q.first == EXISTENTIAL) ? names_phi_ : names_ksi_;
    for (const Var& v : q.second)
    {
      renaming_scheme_[x] = v;
      variable_depth[x] = x_l;
      names[v] = x;
      quant.second.push_back(x);
      quant_inc.second.push_back(x);
      x += 2;
    }
    x_l++;
    
    formula_.pref.push_back(quant);
    formula_.pref_inc.push_back(quant_inc);
  }
  
  // rename the literals in the clauses
  vector<Lit> clause_part_phi;
  vector<Lit> clause_part_ksi;
  vector<Lit> clause_whole;
  
  for (const vector<Lit>& clause : cnf)
  {
    clause_part_phi.clear();
    clause_part_ksi.clear();
    clause_whole.clear();
    
    for (const Lit& literal : clause)
    {
      Var v = var(literal);
      
      if (names_phi_[v] != (Var) -1)
      {
        clause_part_phi.push_back(mkLit(names_phi_[v], sign(literal)));
        clause_whole.push_back(mkLit(names_phi_[v], sign(literal)));
      }
      else if (names_ksi_[v] != (Var) -1)
      {
        clause_part_ksi.push_back(mkLit(names_ksi_[v], sign(literal)));
      }
    }
    
    std::sort(clause_part_phi.begin(), clause_part_phi.end(), orderLits);
    std::sort(clause_part_ksi.begin(), clause_part_ksi.end(), orderLits);
    // std::cout << clause_part_phi;
    // std::cout << clause_part_ksi;
    
    if (clause_part_phi.size() != 0)
    {
      int depth = variable_depth[var(clause_part_phi.back())];
      while (clause_part_ksi.size() != 0)
      {
        if (variable_depth[var(clause_part_ksi.back())] > depth)
          clause_part_ksi.pop_back();
        else
          break;
      }
    }
    
    clause_whole.insert(clause_whole.end(), clause_part_ksi.begin(), clause_part_ksi.end());
    std::sort(clause_whole.begin(), clause_whole.end());
    
    formula_.phi_part.push_back(clause_part_phi);
    formula_.ksi_part.push_back(clause_part_ksi);
    formula_.cnf.push_back(clause_whole);
  }
  
  independent_phi_ = formula_.pref.front().second;
}

void MySolver::instantiateDepQBF()
{
  depqbf_ = qdpll_create();
  
  unsigned int depth = 1;
  for (const Quantification& q : formula_.pref)
  {
    qdpll_new_scope_at_nesting(depqbf_, (q.first == EXISTENTIAL) ? QDPLL_QTYPE_EXISTS : QDPLL_QTYPE_FORALL, depth);
    for (const Var& v : q.second)
    {
      qdpll_add(depqbf_, v);
    }
    qdpll_add(depqbf_, 0);
    depth++;
  }
  
  for (const vector<Lit>& clause : formula_.cnf)
  {
    for (const Lit& lit : clause)
    {
      qdpll_add(depqbf_, lit);
    }
    qdpll_add(depqbf_, 0);
  }
}

void MySolver::retrieveDependencies()
{
  vector<vector<Var>> simple_deps_phi;
  vector<vector<Var>> simple_deps_ksi;
  
  simple_deps_phi.resize(layer_size_phi_);
  simple_deps_ksi.resize(layer_size_ksi_);
  
  cout << "c Starting simple dependency calculation." << endl << std::flush;
  
  bool timed_out = false;
  double time0 = read_cpu_time();
  qdpll_init_deps(depqbf_);
  
  unsigned int* dependant_variables = new unsigned int[max_id_ + 1];
  
  for (const Quantification& q : formula_.pref)
  {
    for (const Var& v : q.second)
    {
      if (read_cpu_time() - time0 > options_.dep_timeout)
      {
        timed_out = true;
        break;
      }
      qdpll_return_deps(depqbf_, v, dependant_variables);
      int pos = 0;
      Var p = 0;
      while (dependant_variables[pos] != 0)
      {
        p = dependant_variables[pos];
        if (v % 2 != p % 2)
        {
          vector<Var>& deps = (p % 2 == 1) ? simple_deps_phi[LAYERP_INDEX(p)] : simple_deps_ksi[LAYERK_INDEX(p)];
          deps.push_back(v);
        }
        pos++;
      }
      debugn("");
    }
    if (timed_out)
      break;
  }
  
  delete[] dependant_variables;
  
  if(options_.heretic_mode == SolverOptions::HereticMode::NO_HERESY)
  {
    qdpll_delete(depqbf_);
  }
  else
  {
    qdpll_reset_deps(depqbf_);
    qdpll_reset(depqbf_);
  }
  
  if (timed_out)
  {
    options_.dependencies = false;
    cout << "c Simple dependency calculation timed out." << endl << std::flush;
    return;
  }
  
  cout << "c Simple dependency calculation took " << read_cpu_time() - time0 << " seconds." << endl << std::flush;
  
  debugn("Simple dependencies in PHI: ");
  for (unsigned i = 0; i < layer_size_phi_; i++)
  {
    debugn(LAYERP_INVERSE(i) << " : " << simple_deps_phi[i]);
  }
  
  debugn("Simple dependencies in KSI: ");
  for (unsigned i = 0; i < layer_size_ksi_; i++)
  {
    debugn(LAYERK_INVERSE(i) << " : " << simple_deps_ksi[i]);
  }
  
  cout << "c Merging dependencies." << endl << std::flush;
  
  mergeDependencies(PHI, simple_deps_phi);
  mergeDependencies(KSI, simple_deps_ksi);
  
  for (const auto& it : deps_phi_)
  {
    if (it.top.empty())
    {
      independent_phi_ = it.bottom;
      break;
    }
  }
  
  cout << "c Dependencies are now merged." << endl << std::flush;
  
  debug({
        cout << "Merged dependencies in PHI:" << endl;
        for (const auto& it : deps_phi_)
        {
          cout << it.bottom << " : " << it.top << endl;
        }
        
        cout << "Merged dependencies in KSI:" << endl;
        for (const auto& it : deps_ksi_)
        {
          cout << it.bottom << " : " << it.top << endl;
        }
  });
  debugn("");
}

void MySolver::mergeDependencies(FormulaType type, const vector<vector<Var>>& source)
{
  vector<DependencyPair>& deps = (type == PHI) ? deps_phi_ : deps_ksi_;
  vector<bool> done;
  done.resize((type == PHI) ? layer_size_phi_ : layer_size_ksi_);
  unsigned current = (unsigned) -1;
  unsigned next = 0;
  Var insert_var = 0;
  while (current != next && next < done.size())
  {
    current = next;
    done[current] = true;
    insert_var = (type == PHI) ? LAYERP_INVERSE(current) : LAYERK_INVERSE(current);
    deps.push_back(DependencyPair(source[current], vector<Var>(1, insert_var)));
    for (unsigned comp = current + 1; comp < source.size(); comp++)
    {
      if (done[comp])
        continue;
      if (source[current] == source[comp])
      {
        done[comp] = true;
        insert_var = (type == PHI) ? LAYERP_INVERSE(comp) : LAYERK_INVERSE(comp);
        deps.back().bottom.push_back(insert_var);
      }
      else if (next == current)
      {
        next = comp;
      }
    }
  }
}
