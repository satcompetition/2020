/* 
 * File:   qtypes.hh
 * Author: mikolas
 *
 * Created on January 12, 2011, 5:32 PM
 */

/** @file */

#ifndef Q2TYPES_HH
#define  Q2TYPES_HH

#include <vector>
#include <map>
#include <iostream>
#include <assert.h>

using std::vector;
using std::ostream;

typedef unsigned Var;
typedef signed Lit;

/**
 * Type of a Quantification
 */
enum QuantifierType
{
  UNIVERSAL, EXISTENTIAL
};

/**
 * Type of a formula used in the QBF solver
 */
enum FormulaType
{
  PHI, KSI
};

class MySolver;

/**
 * Structure representing a quantified vector of boolean variables, represented by their ids.
 */
struct Quantification
{
  /**
   * Simple assignment constructor for WorkerArgument objects.
   * @param q QuantifierType of the quantified bitvector
   * @param vars variables which are quantified in this Quantification
   */
  Quantification(const QuantifierType q, const vector<Var>& vars);
  /**
   * Default Constructor
   */
  Quantification();
  
  QuantifierType first; ///< type of the quantified bitvector
  vector<Var> second;   ///< variables which are quantified
};

/**
 * Vector of Quantification objects.
 */
typedef vector<Quantification> Prefix;

/**
 * Matrix of Lit objects.
 */
typedef vector<vector<Lit>> CNF;

/**
 * Structure used for ranking importance of variables. Used in MySolver::reorderQuantifiersInternally()
 */
struct VarScore
{
  /**
   * Simple assignment constructor for VarScore objects.
   * @param v a variable
   * @param s score of the variable
   */
  VarScore(Var v, unsigned s);
  
  Var v;          ///< the variable that is scored
  unsigned score; ///< the score of the scored variable
};

/**
 * Less-Than operator for VarScore objects
 * @param a first VarScore operand
 * @param b second VarScore operand
 * @return true if variable in a has a lower score than the variable in b, false otherwise
 */
bool operator<(const VarScore& a, const VarScore& b);

/**
 * Structure representing a dependency relation between two vectors of variables. In this relation bottom is dependent
 * upon top. Dependency in this case means that a value to one variable cannot be assigned before a value fo the other
 * is known. A variable can only be dependant upon variables taht come before it in the prefix of the CNF.
 */
struct DependencyPair
{
  /**
   * Simple assignment constructor for DependencyPair objects.
   * @param t vector of upstream variables
   * @param b vector of downsream variables
   */
  DependencyPair(const vector<Var>& t, const vector<Var>& b);
  
  vector<Var> top;    ///< variables in top are depended upon by variables in bottom
  vector<Var> bottom; ///< variables in bottom depend on variables in top
};

/**
 * Equivalence operator for Var vectors.
 * @param a fisrt operand
 * @param b second operand
 * @return true if all elements are equivalent
 */
bool operator==(const vector<Var>& a, const vector<Var>& b);

/**
 * Internal representation of a QBF, where clauses are also spli into the existential and universal part, in order to
 * speed up the acces when fomrulas PHI and KSI are expanded.
 * @see MySolver::extendPHI()
 * @see MySolver::extendKSI()
 */
struct QuantifiedFormula
{
  Prefix pref;     ///< the prefix of the QBF
  Prefix pref_inc; ///< the cumulative prefixes of the QBF
  CNF cnf;         ///< the cnf part of the QBF
  CNF phi_part;    ///< existential parts of the cnf
  CNF ksi_part;    ///< universal parts of the cnf
};

/**
 * Struct containing options, which are passed to the MySolver Constructor.
 * @see MySolver::MySolver()
 */
struct SolverOptions
{
public:
  
  /**
   * Different trimming modes
   */
  enum TrimmingMode
  {
    NO_TRIMMING,
    PERIODIC_TRIMMING,
    LUBY_TRIMMING
  };
  
  enum HereticMode
  {
    NO_HERESY,
    PERIODIC_HERESY,
    PHASE_HERESY
  };
  
  /**
   * Initialises all member variables to default values.
   */
  SolverOptions();
  
  /**
   * Member function for parsing options given as a command line input.
   * @param argc Number of arguments
   * @param argv Null terminated vector of arguments
   * @return true if the parsing was successful, false otherwise
   */
  bool parse(int argc, char** argv);
  
  static const bool DEFAULT_REORDER = false;              ///< Default value for SolverOptions::reorder
  static const bool DEFAULT_SCORING = true;               ///< Default value for SolverOptions::scoring
  static const bool DEFAULT_VARIABLE_ELIMINATION = false; ///< Default value for SolverOptions::variable_elimination
  static const bool DEFAULT_DEDUPLICATION = false;        ///< Default value for SolverOptions::deduplication
  static const bool DEFAULT_DEPENDENCIES = true;          ///< Default value for SolverOptions::dependencies
  static const long DEFAULT_DEP_TIMEOUT = 20;             ///< Default value for SolverOptions::dep_timeout
  static const unsigned long DEFAULT_CEX_PER_CALL = 1;    ///< Default value for SolverOptions::cex_per_call
  static const unsigned long DEFAULT_WIT_PER_CALL = -1;   ///< Default value for SolverOptions::wit_per_call
  static const long DEFAULT_CEX_ORDER = 1;                ///< Default value for SolverOptions::cex_order
  static const long DEFAULT_WIT_ORDER = 1;                ///< Default value for SolverOptions::wit_order
  
  static const TrimmingMode DEFAULT_TRIMMING_PHI = PERIODIC_TRIMMING; ///< Default value for SolverOptions::trimming_phi
  static const unsigned long DEFAULT_TRIMMING_INTERVAL = 200;   ///< Default value for SolverOptions::trimming_interval
  static const unsigned long DEFAULT_LUBY_BASE = 8;             ///< Default multiplier for SolverOptions::trimming_base
  
  static const HereticMode DEFAULT_HERETIC_MODE = NO_HERESY;    ///< Default value for SolverOptions::heretic_mode
  static const bool DEFAULT_HERETIC_LEARN = true;               ///< Default value for SolverOptions::heretic_learn
  static const long DEFAULT_HERETIC_MAX_CLAUSE_SIZE = 50;       ///< Default value for SolverOptions::heretic_clause_size
  static const long DEFAULT_DEPQBF_TIMEOUT = 300;          ///< Default value for SolverOptions::first_phase_timeout
  static const long DEFAULT_HERETIC_PERIOD = 20;                ///< Default value for SolverOptions::heretic_period
  
  bool heretic_learn;         ///< Should the clauses learned by depqbf in heretic mode be reused in second phase
  bool reorder;               ///< Should the variables in a quantifier be reordered
  bool scoring;               ///< Should the cex and wit used for expansion be selected in a smart way
  bool variable_elimination;  ///< Should variables in one expansion be eliminated via unit propagation
  bool deduplication;         ///< Should double addition of the same claues be prevented
  bool dependencies;          ///< Should variable dependencies be used
  long dep_timeout;           ///< Timeout given for dependency calculation
  unsigned long cex_per_call; ///< Number of counter examples to be added per call
  unsigned long wit_per_call; ///< Number of witness examples to be added per call
  
  // +1  for normal order
  // -1 for reverse order
  long cex_order;             ///< In which order are the counter examples added
  
  // +1  for normal order
  // -1 for reverse order
  long wit_order;             ///< In which order are the witness examples added
  
  TrimmingMode trimming_phi;        ///< Specifies the trimming mode used when trimming the formula
  unsigned long trimming_interval;  ///< If trimming mode is periodic, do trimming every so many calls
  unsigned long trimming_base;      ///< Multiplier for the luby sequence used to determine when o trim the formula
  HereticMode heretic_mode;         ///< Should depqbf be used as an incremental qdpll solver
  long heretic_clause_size;         ///< Maximum size of a clause learned from heretic mode
  long qdpll_timeout;              ///< Timeout given to depqbf in heretic mode HereticMode::PHASE_HERESY
  long heretic_period;              ///< Time given for one run of ijtihad and depqbf
};

/**
 * Retrieves the variable associated with the given literal.
 * @param lit literal of the desired variable
 * @return variable of the literal
 */
Var var(Lit lit);

/**
 * Retrieves the sign of the given literal.
 * @param lit literal whose sign is desired
 * @return true if the variable was negated, false otherwise
 */
bool sign(Lit lit);

/**
 * Creates a literal from a variable and a sign
 * @param v a variable
 * @param sign whether the variable is to be negated
 * @return negated variable if sign is true, simple variable if sign is false
 */
Lit mkLit(Var v, bool sign = false);

/**
 * Changes the sign of the input literal.
 * @param lit a literal
 * @return negated literal
 */
Lit negateLit(Lit lit);

/**
 * Introduces an order to the literals. A literal is smaller if it's variable index is smaller. If two literals have
 * the same variable, the negated one is smaller.
 * @param a first literal operand
 * @param b second literal operand
 * @return true if first operand is smaller than the second
 */
bool orderLits(Lit a, Lit b);

ostream& operator<<(ostream& outs, QuantifierType q);

ostream& operator<<(ostream& outs, const QuantifiedFormula& f);

ostream& operator<<(ostream& outs, const CNF& f);

ostream& operator<<(ostream& outs, const Prefix& ls);

ostream& operator<<(ostream& outs, const vector<Var>& vs);

ostream& operator<<(ostream& outs, const vector<Lit>& ls);

#endif	/* Q2TYPES_HH */

