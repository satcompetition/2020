namespace incplan {
	template <class T>
	inline void UNUSED( T const & result ) { static_cast<void>(result); }
}
