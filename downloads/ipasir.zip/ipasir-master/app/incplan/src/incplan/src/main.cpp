int incplan_main(int argc, const char **argv);

int main(int argc, const char **argv) {
	return incplan_main(argc, argv);
}